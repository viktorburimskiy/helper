# bd-infra
A development big data infrastructure with docker-compose.
<br> In this platform, you will have  HDFS, Hive, Spark, Hue, Zeppelin, Kafka, Zookeeper, and Streamsets connected together.
<br> Just run `docker-compose up` and enjoy!
